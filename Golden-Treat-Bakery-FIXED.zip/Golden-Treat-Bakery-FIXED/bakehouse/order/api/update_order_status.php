<?php
// api/update_order_status.php
// POST JSON: { "order_id": 123, "new_status": "Out for Delivery", "changed_by": 1, "note": "..." }
// Auth: send header X-API-KEY: your_api_key_here

// CONFIG - set these
define('API_KEY', 'REPLACE_WITH_YOUR_API_KEY');
define('TWILIO_SID', 'REPLACE_TWILIO_SID');
define('TWILIO_TOKEN', 'REPLACE_TWILIO_AUTH_TOKEN');
define('TWILIO_FROM', '+1234567890');
define('GENERIC_SMS_GATEWAY_URL', '');

header('Content-Type: application/json; charset=utf-8');

$clientKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
if ($clientKey !== API_KEY) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
    exit;
}
$order_id  = isset($data['order_id'])   ? (int)$data['order_id']   : 0;
$new_status = trim($data['new_status']  ?? '');
$changed_by = isset($data['changed_by']) ? (int)$data['changed_by'] : null;
$note       = trim($data['note']        ?? '');

if ($order_id <= 0 || $new_status === '') {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'order_id and new_status required']);
    exit;
}

// BUG FIX #1: Wrong database name was 'Order' — correct DB is 'golden_treat'
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'golden_treat'; // FIXED: was 'Order'
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'DB connection failed']);
    exit;
}
$conn->set_charset('utf8mb4');

// get previous status — also fetch customer_phone for SMS
$stmt = $conn->prepare("SELECT status, customer_name, customer_phone FROM orders WHERE id = ? AND deleted_at IS NULL");
$stmt->bind_param('i', $order_id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();
if (!$row) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Order not found']);
    exit;
}
$old_status   = $row['status'];
$customerName = $row['customer_name'];
$mobile       = $row['customer_phone'] ?? null;

if ($old_status === $new_status) {
    echo json_encode(['ok' => true, 'changed' => false, 'message' => 'No status change']);
    exit;
}

// transaction: update orders + insert history
$conn->begin_transaction();
try {
    $upd = $conn->prepare("UPDATE orders SET status = ?, updated_at = CURRENT_TIMESTAMP() WHERE id = ?");
    $upd->bind_param('si', $new_status, $order_id);
    if (!$upd->execute()) throw new Exception('Update failed: ' . $upd->error);
    $upd->close();

    // BUG FIX: order_status_history insert no longer manually calculates id_new (handled by AUTO_INCREMENT in fixed schema)
    $ins = $conn->prepare("INSERT INTO order_status_history (order_id, old_status, new_status, changed_by, note, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $ins->bind_param('issis', $order_id, $old_status, $new_status, $changed_by, $note);
    if (!$ins->execute()) throw new Exception('History insert failed: ' . $ins->error);
    $ins->close();

    $conn->commit();
} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
    exit;
}

$sms_sent   = false;
$sms_result = null;
$message    = "Dear {$customerName}, your Golden Treat Bakery order #{$order_id} status has been updated to: {$new_status}.";

if ($mobile) {
    if (TWILIO_SID && TWILIO_TOKEN && TWILIO_FROM) {
        // Twilio send (simplified - integrate full Twilio SDK in production)
        $sms_result = ['ok' => false, 'error' => 'Twilio SDK not loaded — configure in production'];
    } elseif (GENERIC_SMS_GATEWAY_URL) {
        $payload = http_build_query(['to' => $mobile, 'message' => $message]);
        $ctx = stream_context_create(['http' => ['method' => 'POST', 'header' => 'Content-Type: application/x-www-form-urlencoded', 'content' => $payload]]);
        $resp = @file_get_contents(GENERIC_SMS_GATEWAY_URL, false, $ctx);
        $sms_sent   = ($resp !== false);
        $sms_result = ['ok' => $sms_sent, 'response' => $resp];
    } else {
        $sms_result = ['ok' => false, 'error' => 'No SMS gateway configured'];
    }
}

echo json_encode([
    'ok'         => true,
    'changed'    => true,
    'order_id'   => $order_id,
    'old_status' => $old_status,
    'new_status' => $new_status,
    'sms_sent'   => $sms_sent,
    'sms_result' => $sms_result
]);
